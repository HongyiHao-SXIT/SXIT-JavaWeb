package com.itheima.tlias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TliasApplication {

	public static void main(String[] args) {
		SpringApplication.run(TliasApplication.class, args);
	}

}