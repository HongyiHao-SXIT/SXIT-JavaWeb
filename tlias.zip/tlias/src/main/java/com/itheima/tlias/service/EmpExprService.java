package com.itheima.tlias.service;

public interface EmpExprService {
    
}
