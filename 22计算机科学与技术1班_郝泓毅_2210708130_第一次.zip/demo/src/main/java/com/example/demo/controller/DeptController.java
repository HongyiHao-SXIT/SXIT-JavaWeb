package com.example.demo.controller;

import com.example.demo.entity.*;
import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/depts")
public class DeptController {

    @PostMapping("/AddDept")
    public String AddDept(@RequestBody Dept dept) {
        System.out.println("新增的部门" + dept);
        return "success";
    }
    
    @DeleteMapping("{id}")
    public String deleteById(@PathVariable("id") Integer id) {
        System.out.println("删除部门:" + id);
        return "success";
    }
    
    @PutMapping
    public String update(@RequestBody Dept dept) {
        System.out.println("修改部门:" + dept);
        return "success";
    }

    @GetMapping("{id}")
    public Dept findById(@PathVariable("id") Integer id) {
        System.out.println("根据id查询部门:" + id);
        Dept dept = new Dept();
        dept.setId(id);
        dept.setName("人事部");
        dept.setUser("张三");
        return dept;
    }

    @GetMapping
    public List<Dept> list() {
        System.out.println("查询所有部门");

        List<Dept> list = new ArrayList<>();

        Dept dept1 = new Dept();
        dept1.setId(1);
        dept1.setName("人事部");
        dept1.setUser("张三");

        Dept dept2 = new Dept();
        dept2.setId(2);
        dept2.setName("教研部");
        dept2.setUser("李四");

        Dept dept3 = new Dept();
        dept3.setId(3);
        dept3.setName("财务部");
        dept3.setUser("王五");

        list.add(dept1);
        list.add(dept2);
        list.add(dept3);

        return list;
    }
}